Sample configuration files for:

SystemD: believed.service
Upstart: believed.conf
OpenRC:  believed.openrc
         believed.openrcconf
CentOS:  believed.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
